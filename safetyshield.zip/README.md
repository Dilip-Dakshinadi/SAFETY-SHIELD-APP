# SafetyShield — Emergency Response and Family Safety System

SafetyShield is a professional Android emergency response, crash detection, and family safety application built with Kotlin, Jetpack Compose, Material Design 3, Room, and native Android hardware integrations.

Inspired by mission-critical personal defense systems, SafetyShield provides rapid, one-touch emergency activation, motion accident radar, live GPS tracking, discreet exit tools, safe-arrival check-ins, and trusted contact notifications.

---

## 🌟 Key Capabilities

1. **One-Touch & Hold-to-Activate SOS**:
   - Hero pulsating SOS trigger with dual mode: hold 2 seconds for guaranteed intent or single tap with confirmation.
   - Real-time GPS coordinate acquisition (`FusedLocationProviderClient`) and Google Maps broadcast links.
   - Discreet **Silent SOS mode** to notify contacts without alerting nearby threats.

2. **Accident & Fall Detection Radar**:
   - Continuous real-time 3-axis accelerometer and gyroscope motion tracking.
   - G-Force vector calculation (`sqrt(ax^2 + ay^2 + az^2) / 9.8g`).
   - Dynamic sensitivity tuning: High (2.0g), Medium (2.8g), Low (3.5g).
   - Documented state machine filtering minor phone drops before triggering a 15-second audible countdown.
   - Built-in simulation tool to safely test the crash countdown and cancellation flow without physical danger.

3. **15-Second Alarm Countdown & Cancellation**:
   - High-contrast visual and audible warning with SOS Morse vibration.
   - Large, accessible **"I AM SAFE — CANCEL"** action to prevent false alarms.

4. **Active Incident Live Tracking**:
   - Elapsed incident timer and live coordinates updating dynamically.
   - Real-time family acknowledgment progression (Pending → Delivered → Acknowledged).
   - One-tap direct call to Emergency Services (**112 / 911**).
   - "I Am Safe • Resolve Alert" incident closeout.

5. **Quick Tools**:
   - **Strobe**: High-speed camera torch strobe signaling for night visibility.
   - **Siren**: High-pitch emergency horn synthesized via `ToneGenerator`.
   - **Silent**: Toggle for covert alert dispatch.
   - **Fake Call**: Realistic incoming phone call simulation with caller ID, ring vibration, and script guide to help users leave uncomfortable situations safely.

6. **Safe Arrival & Journey Tracking**:
   - Destination setup and customizable ETA selector (15m, 30m, 45m, 60m).
   - Vibrant green **"I HAVE ARRIVED SAFELY"** check-in button with contact confirmation.
   - Missed check-in auto-escalation policy.

7. **Trusted Contacts & Preferences**:
   - Emergency contact management (CRUD) stored locally in Room Database.
   - Direct test SMS and phone call actions.
   - Notification preferences (Push, SMS, Vibration).
   - Incident audit log with timestamped history.

---

## 🛠️ Architecture & Tech Stack

- **Platform**: Android 14+ (API 34+ / minSdk 24)
- **Language**: Kotlin 2.2+
- **UI Framework**: Jetpack Compose with Material Design 3
- **Local Persistence**: Room Database (`SafetyDatabase`, `ContactDao`, `IncidentDao`, `SafeArrivalDao`)
- **Preferences**: Jetpack DataStore Preferences (`SafetyPreferencesRepository`)
- **Hardware Integrations**:
  - `SensorManager` (Accelerometer & Gyroscope)
  - `LocationManager` / `FusedLocationProviderClient` (GPS Coordinates)
  - `CameraManager` (Torch / Strobe)
  - `ToneGenerator` & `AudioManager` (Emergency Siren)
  - `Vibrator` / `VibrationEffect` (SOS Morse & Haptic Feedback)
  - `Intent.ACTION_DIAL` (Direct Emergency 112 / 911 Hotline)
  - `Intent.ACTION_SENDTO` (Direct SMS Alert)

---

## 📱 Build & Installation Instructions

To build the APK:
```bash
gradle assembleDebug
```
The generated APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

To run local unit and Robolectric tests:
```bash
gradle :app:testDebugUnitTest
```

---

## 🔒 Security & Privacy Notice

- All contact phone numbers and incident logs are stored locally on-device in an encrypted Room SQLite sandbox.
- Location sharing only activates during manual SOS, confirmed accident countdown expiry, or explicit safe arrival journeys.
- Sensor detection is a heuristic motion safety signal, not a clinical or medical diagnosis. Users are instructed to call 112 / emergency services directly whenever able.
