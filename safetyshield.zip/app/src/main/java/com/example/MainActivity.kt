package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CarCrash
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CarCrash
import androidx.compose.material.icons.outlined.DirectionsRun
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.DetectionType
import com.example.ui.EmergencyState
import com.example.ui.SafetyViewModel
import com.example.ui.accident.AccidentMonitoringScreen
import com.example.ui.active.ActiveEmergencyScreen
import com.example.ui.arrival.SafeArrivalScreen
import com.example.ui.contacts.ContactsAndSettingsScreen
import com.example.ui.countdown.CountdownOverlay
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.fakecall.FakeCallOverlay
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyElevated
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmergencyCrimson
import com.example.ui.theme.SafetyShieldTheme

enum class SafetyNavTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    SAFETY("Safety", Icons.Filled.Security, Icons.Outlined.Security, "nav_tab_safety"),
    ACCIDENT("Monitor", Icons.Filled.CarCrash, Icons.Outlined.CarCrash, "nav_tab_accident"),
    ARRIVAL("Arrival", Icons.Filled.DirectionsRun, Icons.Outlined.DirectionsRun, "nav_tab_arrival"),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_tab_settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SafetyShieldTheme {
                SafetyShieldApp()
            }
        }
    }
}

@Composable
fun SafetyShieldApp(viewModel: SafetyViewModel = viewModel()) {
    var selectedTab by remember { mutableStateOf(SafetyNavTab.SAFETY) }

    // Request necessary runtime permissions (location, notifications)
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Permissions handled gracefully inside EmergencyHardwareManager
    }

    LaunchedEffect(Unit) {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    // State collections
    val emergencyState by viewModel.emergencyState.collectAsStateWithLifecycle()
    val fakeCallState by viewModel.fakeCallState.collectAsStateWithLifecycle()
    val isStrobeActive by viewModel.isStrobeActive.collectAsStateWithLifecycle()
    val isSirenActive by viewModel.isSirenActive.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val incidents by viewModel.incidents.collectAsStateWithLifecycle()
    val latestJourney by viewModel.latestJourney.collectAsStateWithLifecycle()

    // Back handling
    if (selectedTab != SafetyNavTab.SAFETY) {
        BackHandler {
            selectedTab = SafetyNavTab.SAFETY
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidian)
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = DarkObsidian,
            bottomBar = {
                NavigationBar(
                    containerColor = DarkNavySurface,
                    contentColor = Color.White,
                    modifier = Modifier
                        .border(1.dp, DarkNavyBorder)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    SafetyNavTab.values().forEach { tab ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = EmergencyCrimson,
                                selectedTextColor = EmergencyCrimson,
                                unselectedIconColor = Color(0xFF64748B),
                                unselectedTextColor = Color(0xFF64748B),
                                indicatorColor = DarkNavyElevated
                            ),
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    SafetyNavTab.SAFETY -> DashboardScreen(
                        isStrobeActive = isStrobeActive,
                        isSirenActive = isSirenActive,
                        isSilentMode = settings.silentSosMode,
                        onTriggerSos = { viewModel.triggerManualSos() },
                        onToggleStrobe = { viewModel.toggleStrobe() },
                        onToggleSiren = { viewModel.toggleSiren() },
                        onToggleSilent = { viewModel.toggleSilentSos() },
                        onTriggerFakeCall = { viewModel.triggerFakeCall() },
                        onCallEmergencyServices = { viewModel.callEmergencyServices() }
                    )

                    SafetyNavTab.ACCIDENT -> AccidentMonitoringScreen(
                        telemetry = telemetry,
                        sensitivity = settings.sensorSensitivity,
                        onSelectSensitivity = { viewModel.updateSensitivity(it) },
                        onSimulateCrash = { viewModel.startCountdown(DetectionType.MOTION_ACCIDENT) }
                    )

                    SafetyNavTab.ARRIVAL -> SafeArrivalScreen(
                        currentJourney = latestJourney,
                        onStartJourney = { dest, eta -> viewModel.startSafeArrival(dest, eta) },
                        onMarkArrived = { journey -> viewModel.markArrivalSafe(journey) },
                        onResetJourney = { viewModel.clearJourneys() }
                    )

                    SafetyNavTab.SETTINGS -> ContactsAndSettingsScreen(
                        contacts = contacts,
                        incidents = incidents,
                        settings = settings,
                        onAddContact = { n, r, p -> viewModel.addEmergencyContact(n, r, p) },
                        onDeleteContact = { id -> viewModel.deleteContact(id) },
                        onCallContact = { p -> viewModel.callContact(p) },
                        onSmsContact = { p, n -> viewModel.sendContactSms(p, n) },
                        onToggleAutoNight = { viewModel.updateAutoNight(it) },
                        onToggleSilentSos = { viewModel.preferencesRepository.run { viewModel.toggleSilentSos() } },
                        onTogglePush = { viewModel.updatePushAlerts(it) },
                        onToggleSms = { viewModel.updateSmsAlerts(it) },
                        onToggleVibration = { viewModel.updateVibration(it) },
                        onSelectCountdown = { viewModel.updateCountdown(it) },
                        onClearHistory = { viewModel.clearIncidentHistory() }
                    )
                }
            }
        }

        // Fullscreen Overlays:
        // 1. Countdown Overlay (15s alarm before emergency dispatch)
        if (emergencyState is EmergencyState.Countdown) {
            val countdown = emergencyState as EmergencyState.Countdown
            CountdownOverlay(
                remainingSeconds = countdown.remainingSeconds,
                totalSeconds = countdown.totalSeconds,
                detectionType = countdown.detectionType,
                onCancel = { viewModel.cancelCountdown() }
            )
        }

        // 2. Active Emergency Overlay (Live status, GPS broadcast, family notifications)
        if (emergencyState is EmergencyState.ActiveAlert) {
            val activeAlert = emergencyState as EmergencyState.ActiveAlert
            ActiveEmergencyScreen(
                alertState = activeAlert,
                contacts = contacts,
                onResolveEmergency = { viewModel.resolveEmergency() },
                onDirectEmergencyCall = { viewModel.callEmergencyServices() }
            )
        }

        // 3. Fake Call Overlay (Incoming discreet exit call simulation)
        if (fakeCallState.isActive) {
            FakeCallOverlay(
                fakeCallState = fakeCallState,
                onAnswer = { viewModel.answerFakeCall() },
                onDecline = { viewModel.dismissFakeCall() }
            )
        }
    }
}
