package com.example.service

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.data.model.MotionTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class EmergencyHardwareManager(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyroscope = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private val _telemetry = MutableStateFlow(MotionTelemetry())
    val telemetry: StateFlow<MotionTelemetry> = _telemetry.asStateFlow()

    private val _currentLocation = MutableStateFlow<Location?>(null)
    val currentLocation: StateFlow<Location?> = _currentLocation.asStateFlow()

    private val _isStrobeActive = MutableStateFlow(false)
    val isStrobeActive: StateFlow<Boolean> = _isStrobeActive.asStateFlow()

    private val _isSirenActive = MutableStateFlow(false)
    val isSirenActive: StateFlow<Boolean> = _isSirenActive.asStateFlow()

    private var strobeJob: Job? = null
    private var sirenJob: Job? = null
    private var toneGenerator: ToneGenerator? = null

    var onPotentialAccidentDetected: (() -> Unit)? = null

    // Thresholds
    var impactThresholdG: Float = 2.8f
    private var lastImpactTimestamp: Long = 0

    init {
        startSensorMonitoring()
        requestLocationUpdates()
    }

    fun startSensorMonitoring() {
        sensorManager?.let { sm ->
            accelerometer?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
            gyroscope?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        }
    }

    fun stopSensorMonitoring() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val ax = event.values[0]
                val ay = event.values[1]
                val az = event.values[2]
                val magnitude = sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
                val gForce = magnitude / 9.80665f

                val isSpike = gForce >= impactThresholdG
                val now = System.currentTimeMillis()

                if (isSpike && (now - lastImpactTimestamp > 5000)) {
                    lastImpactTimestamp = now
                    vibrateImpactAlert()
                    onPotentialAccidentDetected?.invoke()
                }

                _telemetry.value = _telemetry.value.copy(
                    ax = ax,
                    ay = ay,
                    az = az,
                    totalG = gForce,
                    isImpactDetected = isSpike
                )
            }
            Sensor.TYPE_GYROSCOPE -> {
                val rot = sqrt(
                    (event.values[0] * event.values[0] +
                     event.values[1] * event.values[1] +
                     event.values[2] * event.values[2]).toDouble()
                ).toFloat()
                _telemetry.value = _telemetry.value.copy(rotationRate = rot)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // Location
    private fun requestLocationUpdates() {
        try {
            val providers = locationManager?.getProviders(true) ?: emptyList()
            var bestLoc: Location? = null
            for (p in providers) {
                val loc = locationManager?.getLastKnownLocation(p)
                if (loc != null && (bestLoc == null || loc.accuracy < bestLoc.accuracy)) {
                    bestLoc = loc
                }
            }
            if (bestLoc != null) {
                _currentLocation.value = bestLoc
            }

            // Register continuous listener
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    _currentLocation.value = location
                }
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }

            if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    5000L,
                    5f,
                    listener
                )
            } else if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    5000L,
                    5f,
                    listener
                )
            }
        } catch (e: SecurityException) {
            Log.w("EmergencyHardware", "Location permission not granted: ${e.message}")
        }
    }

    // Vibration
    fun vibrateEmergencySos() {
        val vibrator = getVibrator()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // SOS Morse Code vibration: ... --- ...
            val timings = longArrayOf(0, 200, 100, 200, 100, 200, 200, 400, 100, 400, 100, 400, 200, 200, 100, 200, 100, 200)
            val amplitudes = intArrayOf(0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255)
            vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(longArrayOf(0, 300, 200, 300), -1)
        }
    }

    fun vibrateImpactAlert() {
        val vibrator = getVibrator()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(800)
        }
    }

    fun vibrateClick() {
        val vibrator = getVibrator()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(50, 180))
        }
    }

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    // Strobe / Torch Mode
    fun toggleStrobe(scope: CoroutineScope) {
        if (_isStrobeActive.value) {
            stopStrobe()
        } else {
            startStrobe(scope)
        }
    }

    private fun startStrobe(scope: CoroutineScope) {
        _isStrobeActive.value = true
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        val cameraId = try { cameraManager?.cameraIdList?.firstOrNull() } catch (e: Exception) { null }

        strobeJob = scope.launch(Dispatchers.Default) {
            var state = false
            while (isActive && _isStrobeActive.value) {
                state = !state
                if (cameraId != null && cameraManager != null) {
                    try {
                        cameraManager.setTorchMode(cameraId, state)
                    } catch (e: Exception) {
                        Log.e("EmergencyHardware", "Torch error: ${e.message}")
                    }
                }
                delay(120)
            }
            if (cameraId != null && cameraManager != null) {
                try {
                    cameraManager.setTorchMode(cameraId, false)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    fun stopStrobe() {
        _isStrobeActive.value = false
        strobeJob?.cancel()
        strobeJob = null
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, false)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    // Siren
    fun toggleSiren(scope: CoroutineScope) {
        if (_isSirenActive.value) {
            stopSiren()
        } else {
            startSiren(scope)
        }
    }

    private fun startSiren(scope: CoroutineScope) {
        _isSirenActive.value = true
        sirenJob = scope.launch(Dispatchers.Default) {
            try {
                toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                while (isActive && _isSirenActive.value) {
                    toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 350)
                    delay(400)
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_ERROR, 350)
                    delay(400)
                }
            } catch (e: Exception) {
                Log.e("EmergencyHardware", "Siren error: ${e.message}")
            } finally {
                toneGenerator?.release()
                toneGenerator = null
            }
        }
    }

    fun stopSiren() {
        _isSirenActive.value = false
        sirenJob?.cancel()
        sirenJob = null
        try {
            toneGenerator?.stopTone()
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {
            // ignore
        }
    }

    // Emergency Calling & SMS
    fun launchEmergencyCall(phoneNumber: String = "112") {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("EmergencyHardware", "Error launching call: ${e.message}")
        }
    }

    fun sendEmergencySms(phoneNumber: String, message: String) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
                putExtra("sms_body", message)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("EmergencyHardware", "Error sending SMS: ${e.message}")
        }
    }

    fun cleanUp() {
        stopSensorMonitoring()
        stopStrobe()
        stopSiren()
    }
}
