package com.example.data.model

enum class IncidentStatus {
    PENDING,
    SUBMITTED,
    DELIVERED,
    ACKNOWLEDGED,
    RESOLVED,
    CANCELLED
}

enum class DetectionType {
    MANUAL_SOS,
    MOTION_ACCIDENT,
    FALL_DETECTED,
    SAFE_ARRIVAL_MISSED
}

enum class NotificationChannelType {
    PUSH,
    SMS,
    CALL
}

data class EmergencyContact(
    val id: Long = 0,
    val contactName: String,
    val relationship: String,
    val phoneNumber: String,
    val notificationPriority: Int = 1,
    val isEnabled: Boolean = true,
    val preferredNotificationChannel: NotificationChannelType = NotificationChannelType.PUSH,
    val isAcknowledged: Boolean = false
)

data class Incident(
    val id: Long = 0,
    val incidentCode: String,
    val timestamp: Long = System.currentTimeMillis(),
    val eventStatus: IncidentStatus = IncidentStatus.PENDING,
    val detectionType: DetectionType = DetectionType.MANUAL_SOS,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationAccuracy: Float? = null,
    val mapsUrl: String? = null,
    val contactsAlertedCount: Int = 0,
    val notes: String = ""
)

data class SafeArrivalJourney(
    val id: Long = 0,
    val destinationName: String,
    val etaMinutes: Int,
    val startedAt: Long = System.currentTimeMillis(),
    val targetArrivalAt: Long = System.currentTimeMillis() + (etaMinutes * 60 * 1000L),
    val isArrived: Boolean = false,
    val isAlertTriggered: Boolean = false
)

data class MotionTelemetry(
    val ax: Float = 0f,
    val ay: Float = 0f,
    val az: Float = 9.8f,
    val totalG: Float = 1.0f,
    val rotationRate: Float = 0f,
    val isImpactDetected: Boolean = false,
    val isMonitoringActive: Boolean = true
)
