package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.DetectionType
import com.example.data.model.IncidentStatus
import com.example.data.model.NotificationChannelType
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "emergency_contacts")
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactName: String,
    val relationship: String,
    val phoneNumber: String,
    val notificationPriority: Int,
    val isEnabled: Boolean,
    val preferredNotificationChannel: String,
    val isAcknowledged: Boolean = false
)

@Entity(tableName = "incidents")
data class IncidentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val incidentCode: String,
    val timestamp: Long,
    val eventStatus: String,
    val detectionType: String,
    val latitude: Double?,
    val longitude: Double?,
    val locationAccuracy: Float?,
    val mapsUrl: String?,
    val contactsAlertedCount: Int,
    val notes: String
)

@Entity(tableName = "safe_arrival_journeys")
data class SafeArrivalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val destinationName: String,
    val etaMinutes: Int,
    val startedAt: Long,
    val targetArrivalAt: Long,
    val isArrived: Boolean,
    val isAlertTriggered: Boolean
)

@Dao
interface ContactDao {
    @Query("SELECT * FROM emergency_contacts ORDER BY notificationPriority ASC")
    fun getAllContacts(): Flow<List<ContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactEntity): Long

    @Update
    suspend fun updateContact(contact: ContactEntity)

    @Query("DELETE FROM emergency_contacts WHERE id = :id")
    suspend fun deleteContact(id: Long)

    @Query("SELECT COUNT(*) FROM emergency_contacts")
    suspend fun getCount(): Int
}

@Dao
interface IncidentDao {
    @Query("SELECT * FROM incidents ORDER BY timestamp DESC")
    fun getAllIncidents(): Flow<List<IncidentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: IncidentEntity): Long

    @Query("UPDATE incidents SET eventStatus = :status WHERE id = :id")
    suspend fun updateIncidentStatus(id: Long, status: String)

    @Query("DELETE FROM incidents")
    suspend fun clearHistory()
}

@Dao
interface SafeArrivalDao {
    @Query("SELECT * FROM safe_arrival_journeys ORDER BY startedAt DESC LIMIT 1")
    fun getLatestJourney(): Flow<SafeArrivalEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: SafeArrivalEntity): Long

    @Update
    suspend fun updateJourney(journey: SafeArrivalEntity)

    @Query("DELETE FROM safe_arrival_journeys")
    suspend fun clearJourneys()
}

@Database(
    entities = [ContactEntity::class, IncidentEntity::class, SafeArrivalEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SafetyDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun incidentDao(): IncidentDao
    abstract fun safeArrivalDao(): SafeArrivalDao
}
