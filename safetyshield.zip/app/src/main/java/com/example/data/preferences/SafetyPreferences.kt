package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "safetyshield_preferences")

data class SafetySettings(
    val silentSosMode: Boolean = false,
    val autoActivateNight: Boolean = true,
    val pushNotificationsEnabled: Boolean = true,
    val smsAlertsEnabled: Boolean = true,
    val vibrationAlertsEnabled: Boolean = true,
    val countdownDurationSeconds: Int = 15,
    val sensorSensitivity: String = "Medium" // "Low", "Medium", "High"
)

class SafetyPreferencesRepository(private val context: Context) {
    companion object {
        val KEY_SILENT_SOS = booleanPreferencesKey("silent_sos")
        val KEY_AUTO_NIGHT = booleanPreferencesKey("auto_night")
        val KEY_PUSH_ALERTS = booleanPreferencesKey("push_alerts")
        val KEY_SMS_ALERTS = booleanPreferencesKey("sms_alerts")
        val KEY_VIBRATION = booleanPreferencesKey("vibration")
        val KEY_COUNTDOWN = intPreferencesKey("countdown_seconds")
        val KEY_SENSITIVITY = stringPreferencesKey("sensor_sensitivity")
    }

    val settingsFlow: Flow<SafetySettings> = context.dataStore.data.map { prefs ->
        SafetySettings(
            silentSosMode = prefs[KEY_SILENT_SOS] ?: false,
            autoActivateNight = prefs[KEY_AUTO_NIGHT] ?: true,
            pushNotificationsEnabled = prefs[KEY_PUSH_ALERTS] ?: true,
            smsAlertsEnabled = prefs[KEY_SMS_ALERTS] ?: true,
            vibrationAlertsEnabled = prefs[KEY_VIBRATION] ?: true,
            countdownDurationSeconds = prefs[KEY_COUNTDOWN] ?: 15,
            sensorSensitivity = prefs[KEY_SENSITIVITY] ?: "Medium"
        )
    }

    suspend fun updateSilentSos(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SILENT_SOS] = enabled }
    }

    suspend fun updateAutoNight(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_NIGHT] = enabled }
    }

    suspend fun updatePushAlerts(enabled: Boolean) {
        context.dataStore.edit { it[KEY_PUSH_ALERTS] = enabled }
    }

    suspend fun updateSmsAlerts(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SMS_ALERTS] = enabled }
    }

    suspend fun updateVibration(enabled: Boolean) {
        context.dataStore.edit { it[KEY_VIBRATION] = enabled }
    }

    suspend fun updateCountdownDuration(seconds: Int) {
        context.dataStore.edit { it[KEY_COUNTDOWN] = seconds }
    }

    suspend fun updateSensitivity(level: String) {
        context.dataStore.edit { it[KEY_SENSITIVITY] = level }
    }
}
