package com.example.data.repository

import androidx.room.Room
import android.content.Context
import com.example.data.local.ContactEntity
import com.example.data.local.IncidentEntity
import com.example.data.local.SafeArrivalEntity
import com.example.data.local.SafetyDatabase
import com.example.data.model.DetectionType
import com.example.data.model.EmergencyContact
import com.example.data.model.Incident
import com.example.data.model.IncidentStatus
import com.example.data.model.NotificationChannelType
import com.example.data.model.SafeArrivalJourney
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class SafetyRepository(context: Context) {
    private val db: SafetyDatabase = Room.databaseBuilder(
        context.applicationContext,
        SafetyDatabase::class.java,
        "safetyshield.db"
    ).fallbackToDestructiveMigration().build()

    private val contactDao = db.contactDao()
    private val incidentDao = db.incidentDao()
    private val safeArrivalDao = db.safeArrivalDao()

    init {
        // Pre-populate realistic contacts if empty
        CoroutineScope(Dispatchers.IO).launch {
            if (contactDao.getCount() == 0) {
                seedInitialContacts()
            }
        }
    }

    private suspend fun seedInitialContacts() {
        contactDao.insertContact(
            ContactEntity(
                contactName = "Sarah Mitchell",
                relationship = "Partner",
                phoneNumber = "+1 (415) 555-0192",
                notificationPriority = 1,
                isEnabled = true,
                preferredNotificationChannel = "PUSH",
                isAcknowledged = true
            )
        )
        contactDao.insertContact(
            ContactEntity(
                contactName = "James Carter",
                relationship = "Brother",
                phoneNumber = "+1 (628) 555-0847",
                notificationPriority = 2,
                isEnabled = true,
                preferredNotificationChannel = "SMS",
                isAcknowledged = false
            )
        )
        contactDao.insertContact(
            ContactEntity(
                contactName = "Dr. Emily Ross",
                relationship = "Family Doctor",
                phoneNumber = "+1 (510) 555-0334",
                notificationPriority = 3,
                isEnabled = true,
                preferredNotificationChannel = "CALL",
                isAcknowledged = false
            )
        )
    }

    val contacts: Flow<List<EmergencyContact>> = contactDao.getAllContacts().map { list ->
        list.map { entity ->
            EmergencyContact(
                id = entity.id,
                contactName = entity.contactName,
                relationship = entity.relationship,
                phoneNumber = entity.phoneNumber,
                notificationPriority = entity.notificationPriority,
                isEnabled = entity.isEnabled,
                preferredNotificationChannel = try {
                    NotificationChannelType.valueOf(entity.preferredNotificationChannel)
                } catch (e: Exception) {
                    NotificationChannelType.PUSH
                },
                isAcknowledged = entity.isAcknowledged
            )
        }
    }

    suspend fun addContact(contact: EmergencyContact): Long {
        return contactDao.insertContact(
            ContactEntity(
                contactName = contact.contactName,
                relationship = contact.relationship,
                phoneNumber = contact.phoneNumber,
                notificationPriority = contact.notificationPriority,
                isEnabled = contact.isEnabled,
                preferredNotificationChannel = contact.preferredNotificationChannel.name,
                isAcknowledged = false
            )
        )
    }

    suspend fun updateContact(contact: EmergencyContact) {
        contactDao.updateContact(
            ContactEntity(
                id = contact.id,
                contactName = contact.contactName,
                relationship = contact.relationship,
                phoneNumber = contact.phoneNumber,
                notificationPriority = contact.notificationPriority,
                isEnabled = contact.isEnabled,
                preferredNotificationChannel = contact.preferredNotificationChannel.name,
                isAcknowledged = contact.isAcknowledged
            )
        )
    }

    suspend fun deleteContact(id: Long) {
        contactDao.deleteContact(id)
    }

    val incidents: Flow<List<Incident>> = incidentDao.getAllIncidents().map { list ->
        list.map { entity ->
            Incident(
                id = entity.id,
                incidentCode = entity.incidentCode,
                timestamp = entity.timestamp,
                eventStatus = try {
                    IncidentStatus.valueOf(entity.eventStatus)
                } catch (e: Exception) {
                    IncidentStatus.PENDING
                },
                detectionType = try {
                    DetectionType.valueOf(entity.detectionType)
                } catch (e: Exception) {
                    DetectionType.MANUAL_SOS
                },
                latitude = entity.latitude,
                longitude = entity.longitude,
                locationAccuracy = entity.locationAccuracy,
                mapsUrl = entity.mapsUrl,
                contactsAlertedCount = entity.contactsAlertedCount,
                notes = entity.notes
            )
        }
    }

    suspend fun createIncident(
        detectionType: DetectionType,
        lat: Double?,
        lng: Double?,
        accuracy: Float?,
        contactsCount: Int,
        notes: String = ""
    ): Long {
        val code = "SS-" + UUID.randomUUID().toString().take(6).uppercase()
        val mapsUrl = if (lat != null && lng != null) "https://maps.google.com/?q=$lat,$lng" else null
        return incidentDao.insertIncident(
            IncidentEntity(
                incidentCode = code,
                timestamp = System.currentTimeMillis(),
                eventStatus = IncidentStatus.DELIVERED.name,
                detectionType = detectionType.name,
                latitude = lat,
                longitude = lng,
                locationAccuracy = accuracy,
                mapsUrl = mapsUrl,
                contactsAlertedCount = contactsCount,
                notes = notes
            )
        )
    }

    suspend fun updateIncidentStatus(id: Long, status: IncidentStatus) {
        incidentDao.updateIncidentStatus(id, status.name)
    }

    suspend fun clearIncidentHistory() {
        incidentDao.clearHistory()
    }

    val latestJourney: Flow<SafeArrivalJourney?> = safeArrivalDao.getLatestJourney().map { entity ->
        entity?.let {
            SafeArrivalJourney(
                id = it.id,
                destinationName = it.destinationName,
                etaMinutes = it.etaMinutes,
                startedAt = it.startedAt,
                targetArrivalAt = it.targetArrivalAt,
                isArrived = it.isArrived,
                isAlertTriggered = it.isAlertTriggered
            )
        }
    }

    suspend fun startJourney(destination: String, etaMinutes: Int): Long {
        val now = System.currentTimeMillis()
        return safeArrivalDao.insertJourney(
            SafeArrivalEntity(
                destinationName = destination,
                etaMinutes = etaMinutes,
                startedAt = now,
                targetArrivalAt = now + (etaMinutes * 60 * 1000L),
                isArrived = false,
                isAlertTriggered = false
            )
        )
    }

    suspend fun completeJourney(journey: SafeArrivalJourney) {
        safeArrivalDao.updateJourney(
            SafeArrivalEntity(
                id = journey.id,
                destinationName = journey.destinationName,
                etaMinutes = journey.etaMinutes,
                startedAt = journey.startedAt,
                targetArrivalAt = journey.targetArrivalAt,
                isArrived = true,
                isAlertTriggered = false
            )
        )
    }

    suspend fun clearJourneys() {
        safeArrivalDao.clearJourneys()
    }
}
