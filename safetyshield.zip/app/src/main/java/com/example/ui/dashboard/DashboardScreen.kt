package com.example.ui.dashboard

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.PhoneCallback
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyElevated
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmergencyCrimson
import com.example.ui.theme.SafetyEmerald
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(
    isStrobeActive: Boolean,
    isSirenActive: Boolean,
    isSilentMode: Boolean,
    onTriggerSos: () -> Unit,
    onToggleStrobe: () -> Unit,
    onToggleSiren: () -> Unit,
    onToggleSilent: () -> Unit,
    onTriggerFakeCall: () -> Unit,
    onCallEmergencyServices: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var holdProgress by remember { mutableStateOf(0f) }
    var isHolding by remember { mutableStateOf(false) }
    var holdJob by remember { mutableStateOf<Job?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "halo")
    val haloPulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "haloPulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidian)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PERSONAL SAFETY",
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "SafetyShield",
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }

            // Status Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(DarkNavyElevated, RoundedCornerShape(20.dp))
                    .border(1.dp, DarkNavyBorder, RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(SafetyEmerald, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Connected",
                    color = SafetyEmerald,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Status Capsules Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusPill(
                icon = Icons.Default.Security,
                text = "Shield Pro",
                color = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
            StatusPill(
                icon = Icons.Default.BatteryChargingFull,
                text = "94%",
                color = SafetyEmerald,
                modifier = Modifier.weight(0.8f)
            )
            StatusPill(
                icon = Icons.Default.GpsFixed,
                text = "GPS Active",
                color = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(36.dp))

        // Glowing Hero SOS Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            contentAlignment = Alignment.Center
        ) {
            // Ambient Halo Glow
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .scale(haloPulse)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                EmergencyCrimson.copy(alpha = 0.35f),
                                EmergencyCrimson.copy(alpha = 0.10f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Hold Circular Progress Indicator
            if (isHolding || holdProgress > 0f) {
                CircularProgressIndicator(
                    progress = { holdProgress },
                    modifier = Modifier.size(210.dp),
                    color = Color.White,
                    strokeWidth = 6.dp,
                    trackColor = EmergencyCrimson.copy(alpha = 0.4f)
                )
            }

            // Core SOS Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(190.dp)
                    .shadow(elevation = 20.dp, shape = CircleShape, spotColor = EmergencyCrimson)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                EmergencyCrimson,
                                Color(0xFFC71032)
                            )
                        ),
                        shape = CircleShape
                    )
                    .border(3.dp, Color(0xFFFF6B81), CircleShape)
                    .testTag("sos_button")
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                isHolding = true
                                holdJob = coroutineScope.launch {
                                    val steps = 30
                                    for (i in 1..steps) {
                                        delay(50)
                                        holdProgress = i.toFloat() / steps
                                    }
                                    // Held for 1.5 seconds -> trigger!
                                    onTriggerSos()
                                    holdProgress = 0f
                                    isHolding = false
                                }
                                tryAwaitRelease()
                                isHolding = false
                                holdJob?.cancel()
                                holdProgress = 0f
                            },
                            onTap = {
                                // Direct tap also triggers confirmation
                                onTriggerSos()
                            }
                        )
                    }
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "SOS",
                        color = Color.White,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHolding) "ACTIVATING..." else "Hold for Help",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            text = "Hold 2 seconds to activate emergency",
            color = Color(0xFF64748B),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Quick Tools Section
        Text(
            text = "QUICK TOOLS",
            color = Color(0xFF94A3B8),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickToolCard(
                icon = Icons.Default.FlashOn,
                label = "Strobe",
                isActive = isStrobeActive,
                activeColor = Color(0xFFFFD700),
                onClick = onToggleStrobe,
                modifier = Modifier.weight(1f),
                testTag = "quick_tool_strobe"
            )
            QuickToolCard(
                icon = Icons.Default.VolumeUp,
                label = "Siren",
                isActive = isSirenActive,
                activeColor = EmergencyCrimson,
                onClick = onToggleSiren,
                modifier = Modifier.weight(1f),
                testTag = "quick_tool_siren"
            )
            QuickToolCard(
                icon = Icons.Default.VolumeOff,
                label = "Silent",
                isActive = isSilentMode,
                activeColor = ElectricCyan,
                onClick = onToggleSilent,
                modifier = Modifier.weight(1f),
                testTag = "quick_tool_silent"
            )
            QuickToolCard(
                icon = Icons.Default.PhoneCallback,
                label = "Fake Call",
                isActive = false,
                activeColor = SafetyEmerald,
                onClick = onTriggerFakeCall,
                modifier = Modifier.weight(1f),
                testTag = "quick_tool_fake_call"
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Call 112 Direct Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkNavySurface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkNavyBorder, RoundedCornerShape(16.dp))
                .clickable { onCallEmergencyServices() }
                .testTag("dashboard_call_112")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(EmergencyCrimson.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Emergency Call",
                            tint = EmergencyCrimson,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "Direct Emergency Hotline",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Call 112 / Police, Fire, Ambulance",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                Button(
                    onClick = onCallEmergencyServices,
                    colors = ButtonDefaults.buttonColors(containerColor = EmergencyCrimson),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = ButtonDefaults.TextButtonContentPadding
                ) {
                    Text(
                        text = "112",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun StatusPill(
    icon: ImageVector,
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(DarkNavySurface, RoundedCornerShape(14.dp))
            .border(1.dp, DarkNavyBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun QuickToolCard(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val bgColor = if (isActive) activeColor.copy(alpha = 0.2f) else DarkNavySurface
    val borderColor = if (isActive) activeColor else DarkNavyBorder
    val iconColor = if (isActive) activeColor else Color(0xFF94A3B8)

    Column(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(14.dp))
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = iconColor,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            color = if (isActive) Color.White else Color(0xFF94A3B8),
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
        )
    }
}
