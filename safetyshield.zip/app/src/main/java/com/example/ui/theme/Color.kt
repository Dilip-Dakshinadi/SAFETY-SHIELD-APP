package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkObsidian = Color(0xFF090D16)
val DarkNavySurface = Color(0xFF111726)
val DarkNavyElevated = Color(0xFF182238)
val DarkNavyBorder = Color(0xFF22304E)

val EmergencyCrimson = Color(0xFFFF2A4D)
val EmergencyCrimsonDark = Color(0xFF990F26)
val EmergencyCrimsonGlow = Color(0x33FF2A4D)

val ElectricCyan = Color(0xFF00D2FF)
val ElectricCyanDark = Color(0xFF007799)

val SafetyEmerald = Color(0xFF10B981)
val SafetyEmeraldDark = Color(0xFF065F46)

val WarningAmber = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
