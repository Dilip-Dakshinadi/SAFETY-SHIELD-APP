package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmergencyCrimson,
    onPrimary = Color.White,
    primaryContainer = EmergencyCrimsonDark,
    onPrimaryContainer = Color.White,
    secondary = ElectricCyan,
    onSecondary = Color.Black,
    secondaryContainer = ElectricCyanDark,
    onSecondaryContainer = Color.White,
    tertiary = SafetyEmerald,
    onTertiary = Color.White,
    background = DarkObsidian,
    onBackground = TextPrimary,
    surface = DarkNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkNavyElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkNavyBorder,
    error = EmergencyCrimson,
    onError = Color.White
)

@Composable
fun SafetyShieldTheme(
    darkTheme: Boolean = true, // Default to sleek obsidian dark theme as per safety aesthetics
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
