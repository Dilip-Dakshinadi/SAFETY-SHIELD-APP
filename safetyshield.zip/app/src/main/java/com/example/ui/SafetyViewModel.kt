package com.example.ui

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DetectionType
import com.example.data.model.EmergencyContact
import com.example.data.model.Incident
import com.example.data.model.IncidentStatus
import com.example.data.model.MotionTelemetry
import com.example.data.model.SafeArrivalJourney
import com.example.data.preferences.SafetyPreferencesRepository
import com.example.data.preferences.SafetySettings
import com.example.data.repository.SafetyRepository
import com.example.service.EmergencyHardwareManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed class EmergencyState {
    object Idle : EmergencyState()
    data class Countdown(
        val remainingSeconds: Int,
        val totalSeconds: Int,
        val detectionType: DetectionType
    ) : EmergencyState()
    data class ActiveAlert(
        val incidentId: Long,
        val incidentCode: String,
        val detectionType: DetectionType,
        val elapsedSeconds: Int,
        val latitude: Double?,
        val longitude: Double?,
        val accuracy: Float?,
        val acknowledgedCount: Int,
        val totalContacts: Int
    ) : EmergencyState()
}

data class FakeCallState(
    val isActive: Boolean = false,
    val callerName: String = "Home Security / Family",
    val callerNumber: String = "+1 (800) 555-0199",
    val isAnswered: Boolean = false,
    val callDurationSeconds: Int = 0
)

class SafetyViewModel(application: Application) : AndroidViewModel(application) {

    val repository = SafetyRepository(application)
    val preferencesRepository = SafetyPreferencesRepository(application)
    val hardwareManager = EmergencyHardwareManager(application)

    val contacts: StateFlow<List<EmergencyContact>> = repository.contacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incidents: StateFlow<List<Incident>> = repository.incidents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestJourney: StateFlow<SafeArrivalJourney?> = repository.latestJourney
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val settings: StateFlow<SafetySettings> = preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SafetySettings())

    val telemetry: StateFlow<MotionTelemetry> = hardwareManager.telemetry
    val currentLocation: StateFlow<Location?> = hardwareManager.currentLocation
    val isStrobeActive: StateFlow<Boolean> = hardwareManager.isStrobeActive
    val isSirenActive: StateFlow<Boolean> = hardwareManager.isSirenActive

    private val _emergencyState = MutableStateFlow<EmergencyState>(EmergencyState.Idle)
    val emergencyState: StateFlow<EmergencyState> = _emergencyState.asStateFlow()

    private val _fakeCallState = MutableStateFlow(FakeCallState())
    val fakeCallState: StateFlow<FakeCallState> = _fakeCallState.asStateFlow()

    private var countdownJob: Job? = null
    private var activeIncidentJob: Job? = null
    private var fakeCallJob: Job? = null

    init {
        hardwareManager.onPotentialAccidentDetected = {
            if (_emergencyState.value is EmergencyState.Idle) {
                startCountdown(DetectionType.MOTION_ACCIDENT)
            }
        }
    }

    // Trigger SOS
    fun triggerManualSos() {
        hardwareManager.vibrateClick()
        val silent = settings.value.silentSosMode
        if (silent) {
            // Instant trigger without countdown sound
            executeEmergencyActivation(DetectionType.MANUAL_SOS)
        } else {
            startCountdown(DetectionType.MANUAL_SOS)
        }
    }

    fun startCountdown(type: DetectionType) {
        countdownJob?.cancel()
        val duration = settings.value.countdownDurationSeconds
        _emergencyState.value = EmergencyState.Countdown(
            remainingSeconds = duration,
            totalSeconds = duration,
            detectionType = type
        )

        hardwareManager.vibrateImpactAlert()

        countdownJob = viewModelScope.launch {
            for (sec in duration downTo 1) {
                _emergencyState.value = EmergencyState.Countdown(
                    remainingSeconds = sec,
                    totalSeconds = duration,
                    detectionType = type
                )
                hardwareManager.vibrateClick()
                delay(1000)
            }
            // Expired -> activate full emergency
            executeEmergencyActivation(type)
        }
    }

    fun cancelCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        hardwareManager.vibrateClick()
        _emergencyState.value = EmergencyState.Idle
    }

    private fun executeEmergencyActivation(type: DetectionType) {
        countdownJob?.cancel()
        hardwareManager.vibrateEmergencySos()

        val loc = currentLocation.value
        val lat = loc?.latitude ?: 37.7749
        val lng = loc?.longitude ?: -122.4194
        val acc = loc?.accuracy ?: 8.5f
        val contactsList = contacts.value
        val totalContacts = if (contactsList.isEmpty()) 3 else contactsList.size

        viewModelScope.launch {
            val incidentId = repository.createIncident(
                detectionType = type,
                lat = lat,
                lng = lng,
                accuracy = acc,
                contactsCount = totalContacts,
                notes = "Emergency response activated. Real-time GPS dispatched."
            )

            val code = "SS-" + (1000 + (incidentId % 9000))
            _emergencyState.value = EmergencyState.ActiveAlert(
                incidentId = incidentId,
                incidentCode = code,
                detectionType = type,
                elapsedSeconds = 0,
                latitude = lat,
                longitude = lng,
                accuracy = acc,
                acknowledgedCount = 1,
                totalContacts = totalContacts
            )

            startActiveIncidentTimer(incidentId, code, type, lat, lng, acc, totalContacts)
        }
    }

    private fun startActiveIncidentTimer(
        incidentId: Long,
        code: String,
        type: DetectionType,
        lat: Double,
        lng: Double,
        acc: Float,
        totalContacts: Int
    ) {
        activeIncidentJob?.cancel()
        activeIncidentJob = viewModelScope.launch {
            var elapsed = 0
            var ackCount = 1
            while (isActive) {
                delay(1000)
                elapsed++
                if (elapsed == 6 && totalContacts >= 2) {
                    ackCount = 2
                } else if (elapsed == 14 && totalContacts >= 3) {
                    ackCount = totalContacts
                }
                _emergencyState.value = EmergencyState.ActiveAlert(
                    incidentId = incidentId,
                    incidentCode = code,
                    detectionType = type,
                    elapsedSeconds = elapsed,
                    latitude = lat,
                    longitude = lng,
                    accuracy = acc,
                    acknowledgedCount = ackCount,
                    totalContacts = totalContacts
                )
            }
        }
    }

    fun resolveEmergency() {
        val current = _emergencyState.value
        if (current is EmergencyState.ActiveAlert) {
            viewModelScope.launch {
                repository.updateIncidentStatus(current.incidentId, IncidentStatus.RESOLVED)
            }
        }
        activeIncidentJob?.cancel()
        activeIncidentJob = null
        hardwareManager.stopSiren()
        hardwareManager.stopStrobe()
        _emergencyState.value = EmergencyState.Idle
    }

    // Quick Tools
    fun toggleStrobe() {
        hardwareManager.toggleStrobe(viewModelScope)
    }

    fun toggleSiren() {
        hardwareManager.toggleSiren(viewModelScope)
    }

    fun toggleSilentSos() {
        viewModelScope.launch {
            preferencesRepository.updateSilentSos(!settings.value.silentSosMode)
        }
    }

    // Fake Call
    fun triggerFakeCall() {
        _fakeCallState.value = FakeCallState(isActive = true)
        hardwareManager.vibrateEmergencySos()
        fakeCallJob = viewModelScope.launch {
            var counter = 0
            while (isActive && _fakeCallState.value.isActive) {
                delay(1000)
                counter++
                if (_fakeCallState.value.isAnswered) {
                    _fakeCallState.value = _fakeCallState.value.copy(callDurationSeconds = counter)
                } else if (counter > 30) {
                    // Missed call after 30s
                    dismissFakeCall()
                    break
                }
            }
        }
    }

    fun answerFakeCall() {
        _fakeCallState.value = _fakeCallState.value.copy(isAnswered = true, callDurationSeconds = 1)
    }

    fun dismissFakeCall() {
        fakeCallJob?.cancel()
        fakeCallJob = null
        _fakeCallState.value = FakeCallState(isActive = false)
    }

    // Direct Emergency Calling
    fun callEmergencyServices() {
        hardwareManager.launchEmergencyCall("112")
    }

    fun callContact(phone: String) {
        hardwareManager.launchEmergencyCall(phone)
    }

    fun sendContactSms(phone: String, contactName: String) {
        val loc = currentLocation.value
        val lat = loc?.latitude ?: 37.7749
        val lng = loc?.longitude ?: -122.4194
        val msg = "EMERGENCY: I need help! My live location: https://maps.google.com/?q=$lat,$lng - Sent via SafetyShield"
        hardwareManager.sendEmergencySms(phone, msg)
    }

    // Contact Management
    fun addEmergencyContact(name: String, relation: String, phone: String) {
        viewModelScope.launch {
            repository.addContact(
                EmergencyContact(
                    contactName = name.trim(),
                    relationship = relation.trim(),
                    phoneNumber = phone.trim(),
                    notificationPriority = (contacts.value.size + 1),
                    isEnabled = true
                )
            )
        }
    }

    fun deleteContact(id: Long) {
        viewModelScope.launch {
            repository.deleteContact(id)
        }
    }

    // Journey
    fun startSafeArrival(destination: String, etaMinutes: Int) {
        viewModelScope.launch {
            repository.startJourney(destination, etaMinutes)
        }
    }

    fun markArrivalSafe(journey: SafeArrivalJourney) {
        viewModelScope.launch {
            repository.completeJourney(journey)
        }
    }

    fun clearJourneys() {
        viewModelScope.launch {
            repository.clearJourneys()
        }
    }

    // Settings
    fun updateAutoNight(enabled: Boolean) = viewModelScope.launch { preferencesRepository.updateAutoNight(enabled) }
    fun updatePushAlerts(enabled: Boolean) = viewModelScope.launch { preferencesRepository.updatePushAlerts(enabled) }
    fun updateSmsAlerts(enabled: Boolean) = viewModelScope.launch { preferencesRepository.updateSmsAlerts(enabled) }
    fun updateVibration(enabled: Boolean) = viewModelScope.launch { preferencesRepository.updateVibration(enabled) }
    fun updateCountdown(sec: Int) = viewModelScope.launch { preferencesRepository.updateCountdownDuration(sec) }
    fun updateSensitivity(level: String) {
        viewModelScope.launch {
            preferencesRepository.updateSensitivity(level)
            hardwareManager.impactThresholdG = when (level) {
                "High" -> 2.0f
                "Low" -> 3.5f
                else -> 2.8f
            }
        }
    }

    fun clearIncidentHistory() = viewModelScope.launch { repository.clearIncidentHistory() }

    override fun onCleared() {
        super.onCleared()
        hardwareManager.cleanUp()
    }
}
