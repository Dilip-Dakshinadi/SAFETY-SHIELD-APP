package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DetectionType
import com.example.data.model.EmergencyContact
import com.example.data.model.Incident
import com.example.data.model.IncidentStatus
import com.example.data.model.NotificationChannelType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SafetyShield", appName)
  }

  @Test
  fun `test emergency contact creation and serialization`() {
    val contact = EmergencyContact(
      id = 1L,
      contactName = "Sarah Mitchell",
      relationship = "Partner",
      phoneNumber = "+1 (415) 555-0192",
      notificationPriority = 1,
      isEnabled = true,
      preferredNotificationChannel = NotificationChannelType.PUSH
    )
    assertEquals("Sarah Mitchell", contact.contactName)
    assertEquals("Partner", contact.relationship)
    assertTrue(contact.isEnabled)
  }

  @Test
  fun `test incident creation structure`() {
    val incident = Incident(
      id = 101L,
      incidentCode = "SS-4821",
      eventStatus = IncidentStatus.DELIVERED,
      detectionType = DetectionType.MANUAL_SOS,
      latitude = 37.7749,
      longitude = -122.4194,
      locationAccuracy = 5.0f,
      contactsAlertedCount = 3
    )
    assertEquals("SS-4821", incident.incidentCode)
    assertEquals(IncidentStatus.DELIVERED, incident.eventStatus)
    assertNotNull(incident.latitude)
  }
}
